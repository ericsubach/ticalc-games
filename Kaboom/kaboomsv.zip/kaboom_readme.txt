Updated April 22, 2004.

//////////////////////////////////
/ Kaboom version 1.4 for TI-83+  /
/          and Silver            /
/    Created by: Eric Subach     /
/  Pen name: Bobbert Bobbington  /
/ Email- foehammer01@comcast.net /
//////////////////////////////////

This game is based on the old Atari 2600 game, Kaboom! The only difference is that it only has one bomb at a time and the object is to cath the bomb (multiplication sign) with the buffer (equals sign). It runs extremely slow for the regular TI-83+, but runs very fast on the Silver version. If it does in fact run too fast please feel free to edit the speed (if you can decipher my codeing because this game was done a while back and i never changed the code). The only thing I ask is that if you do not take this game as your own. I will have to trust you. If you do add to or edit the game feel free to include your name. All of my other games have a nifty credits screen. Thank you and enjoy!

Some of my other games include Dancing Dude (with added moves by Joe Brightbill), Simon, Tic-Tac-Toe with AI, and my latest creation, Fight. Some of these will be posted on the TI calc website.

As I have stated before most of these games work better on the Silver version, but were designed on my TI-83+.