Updated April 18, 2004.

////////////ASSEMBLY//////////////
/   Maze for TI 83+ and Silver   /
/    Created by: Eric Subach     /
/  Pen name: Bobbert Bobbington  /
/ Email- foehammer01@comcast.net /
//////////////////////////////////

This game is my first Assembly (ASM) program! It is designed for ION. If you do not have ION, download it at...

http://www.ticalc.org/pub/83plus/asm/shells/ion.zip

It is a maze and you are a pixel. The goal is to get to the end. It was meant to be played once and then deleted. (I might even add more mazes) A major part was for me learing to understand assembly. Instructions included in game menu. Thank you and enjoy!

Some of my games for BASIC include Fight, Dancing Dude (with added moves by Joe Brightbill), Simon, and Tic-Tac-Toe with AI. Some of these will be posted on the TI calc website. Most of these games work better on the Silver version, but were designed on my TI-83+.