Updated April 22, 2004.

//////////////////////////////////
/  Simon for TI 83+ and Silver   /
/    Created by: Eric Subach     /
/  Pen name: Bobbert Bobbington  /
/ Email- foehammer01@comcast.net /
//////////////////////////////////

This game is a remake of the classic simon. Instructions icluded in game menu. Thank you and enjoy!

Some of my other games include Dancing Dude (with added moves by Joe Brightbill), Simon, and Tic-Tac-Toe with AI. Some of these will be posted on the TI calc website.

Most of these games work better on the Silver version, but were designed on my TI-83+.