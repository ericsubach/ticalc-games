Updated October 14, 2004.

///////////////BASIC///////////////
/  Grading for TI 83+ and Silver  /
/    Created by: Eric Subach      /
/             (c) 2004            /
/ Email- foehammer01@comcast.net  /
///////////////////////////////////

This game is a simple grade tracking program. It stores an unlimited amount of grades for six subjects. You can look at all of your entered grades at any time and it also gives an average for each subject. You may store comments for each grade you enter, and they will be seperated by commas to indicate which grade it is associated with. (NOTE: Due to the limitations of the calculator, only a certain number of comments will fit on the screen). Please have strings 1-6 and 0 unarchived, and most variables unarchived. Upon first use of the program, lists will be made to store grading information. (NOTE: if you recieve an error when first using this program store theta [press ALPHA, then 3] as 0. In other words, type in 0->(theta)). Due to the limitaions of the calculator, you may not delete a single grade. If you type incorrect information, I suggest writing everything down on paper and put it back in after resetting the list defaults (NOTE: There is an option in the program which allows you to do this). I am not responsible for any information lost due to a RAM reset, although this program takes precautions in storing your information safely. The only way your information can be lost is if the RAM resets whilst the program is running. Please understand that the program may run slowly or ask you to garbage collect because it is safely storing your information. Always say yes to a garbage collect or you may jeopardize your information. Thank you and enjoy!

If this is not the first time you have downloaded this program, please unarchive strings 1-6 and 0, and lists GRADE and GRAD2 then run the program. This is because of an error that I have corrected. 

Please do not steal this code and take credit.

Please check out my other programs listed under www.ticalc.org
http://www.ticalc.org/archives/files/authors/84/8421.html