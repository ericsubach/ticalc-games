Updated MAy 22, 2004.

/////////////ASSEMBLY//////////////
/Tic-Tac-Toe for TI 83+ and Silver/
/    Created by: Eric Subach      /
/  Pen name: Bobbert Bobbington   /
/ Email- foehammer01@comcast.net  /
///////////////////////////////////

This game is a classic Tic-Tac-Toe in ASSEMBLY. The A.I. is amazing. I dare you to try and win. All directions included in the game menu. Thank you and enjoy! 

Some of my other BASIC games include Dancing Dude , Simon, and Tic-Tac-Toe with AI. These are posted on the TI calc website.

My other ASSEMBLY games include Maze. They also are posted on the TI website.

Most of these BASIC games work better on the Silver version, but were designed on my TI-83+.